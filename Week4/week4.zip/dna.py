import sys
import csv

def max_repetiton(dna, sequence):
    #max_num ve ctr başlangıç değeri olarak 0 alırlar. 
    max_num = 0
    ctr = 0
    #strinler üzerinde kullanıabilen find metodu aranan string parçasının karşılaşıldığı ilk indexi gönderir, yoksa -1 verir.
    index = dna.find(sequence)
    #burada find -1 döndürmemişse ya da index + STR uzunluğu dna'nın içeriisndeyse loop'a girilir.
    while index != -1 and index + len(sequence) <= len(dna):
        #index'ten uzunluğun sonuna dna parçasının STR ile uyumu araştılır.
        if dna[index : index + len(sequence)] == sequence:
            #uyum varsa ctr 1 arttırılır.
            ctr += 1
            index += len(sequence) #consecutive
            #index sequence kadar arttırılır çünklü STR'ların ard arda maksimum sayımlarını bulmaya çalışıyoruz.
        else:
            #eğer sequence'a eşit olmayan bir aralıktaysak ve max_num sayımı ctr'dan küçükse bunun değerini güncelleriz ve ctr'u sıfırlayarak,
            #sequence'ı içeren bir sonraki index'i alıp loop'a geri döneriz.
            if max_num < ctr:
                max_num = ctr
            ctr = 0
            index = dna.find(sequence, index, len(dna))

    return max_num #max tekrar returnlenir.

#sys.argv pythonda verilmiş command line argümanlarını saklayan bir listedir. sys.argv[0] programın ismini ifade eder.
# 3 argüman yoksa yani dna.txt ve data.csv verilmemişse programdan hata mesajı ile çıkılır,
#  bunun kontrolünü listin uzunluğu ile sağlayabiliriz.
if len(sys.argv) != 3: 
    print("Usage: python dna.py data.csv sequence.txt")
    quit()

#count adlı boş bir liste oluşturulur ve csv.DictReader tarafından okunmuş dosyanın her bir dict tipi row'u counts listesine eklenir.
#Yani counts bir dictionary listesidir.
counts = []
with open(sys.argv[1]) as csv_file:
    reader = csv.DictReader(csv_file)
    for row in reader:
        counts.append(row) #append ile listenin sonuna yeni bir dictionary eklenir.
        
#2.argüman yani dna'yı içeren txt dosyası güvenli bir şekilde okunur.
with open(sys.argv[2], "r") as dna_file:
    person_dna = dna_file.read() 

#counts içindeki rowlar üzerinde loop'a girilerek her isim ve sahip oldukları STR miktarları karşılaştırılır.
for row in counts:
    #loop breaked True olunca counts bitmeden sonlandırılacak.
    breaked = False
    
    for key in row.keys():
        if(key == "name"): #isim için karşılaştırma yapılmayacak, sadece STR sayımları üzerinden değerlendirme yapılabiliyor.
            continue
        #alınmış key bir STR dizilimine eşitse max_repetition fonksiyonu çağrılarak bu STR'ın Dna'daki sayımı repetiton olarak kaydedilir.
        repetition = max_repetiton(person_dna, key)
        if repetition != int(row[key]): 
            #eğer şu anki row içerisinde STR key'ine karşılık gelen value
            #repetition'a eşit değilse breaked True'ya dönüştürülür ve ikinci loop'dan break ile çıkılır.
            breaked = True
            break
    #tüm STR valueları Dna ile eşleşen biri bulunursa breaked False kalır 
    # ve onun ismini yazdırarak birinci loop'dan çıkarak programı quit() ile sonlandırabiliriz.
    if not breaked:
        print(row["name"])
        quit()

#eğer  breaked ile loop dışına çıkılmamış ve program sonlanmamışsa herhangi bir eşleşme olamdığından "no match" gönderilir.
print("No match")