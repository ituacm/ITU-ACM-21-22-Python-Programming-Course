class Rectangle:
    def __init__(self, height, width):
        self.height = height
        self.width = width
    
    def Perimeter(self):
        return self.height * 2 + self.width * 2
    
    def Area(self):
        return self.height * self.width

    def display(self):
        print(f"Height of the object: {self.height}\nWidth of the object: {self.width}\nPerimeter of the object: {self.Perimeter()}\nArea of the object: {self.Area()}")
        for i in range(self.height):
            print("#" * self.width) 

    
width = int(input("Enter the width of the rectangle: "))
height = int(input("Enter the height of the rectangle: "))

rect = Rectangle(height, width)
rect.display()